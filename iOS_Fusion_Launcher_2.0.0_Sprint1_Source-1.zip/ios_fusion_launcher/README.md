# iOS Fusion Launcher 2.0.0 — Sprint 1

This is an Android HOME launcher application, not an operating system, ROM, or firmware.
It is an independently implemented launcher using a hybrid iOS 18 + iOS 26 visual direction.

## Sprint 1 implemented in source
- Android HOME / DEFAULT launcher entry point.
- Home screen with clock/date hero, app shortcuts, translucent dock-style navigation.
- Separate App Library screen with live search and heuristic categories.
- Configurable app grid columns, icon size, and app labels.
- Android AppWidgetHost integration: pick, display, configure, persist and remove Android home-screen widgets.
- Wallpaper picker and clock styling settings.
- Control Center-style shortcut page that opens real Android system settings.
- Lock-screen visual preview only; Android secure lock screen remains in control.
- Tap app icon to launch; long-press opens Android App Info.

## Compatibility target
- minSdk 26 (Android 8.0)
- targetSdk 32 (Android 12L)
- Designed for initial testing on OPPO A15s / Android 10.
- Build uses JDK 17, Android Gradle Plugin 8.6.1 and Gradle 8.7.

## Important honest limitations
- This is a first development sprint, not a completed Smart Launcher replacement.
- Widget layout is currently a vertical list with a fixed host-view height; drag-and-drop resizing/repositioning is not implemented yet.
- Categories use app-name heuristics and may need corrections.
- Multi-page drag/drop, folders, icon packs, advanced gestures, and live secure lock-screen replacement are not implemented in this sprint.
- The secure Android lock screen is not replaced.

## Build
Run `gradle --no-daemon assembleDebug` from this project root. The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.
