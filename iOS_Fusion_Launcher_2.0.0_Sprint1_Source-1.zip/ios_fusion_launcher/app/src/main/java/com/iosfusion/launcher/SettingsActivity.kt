package com.iosfusion.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fusion", MODE_PRIVATE) }
    private val white = Color.WHITE
    private val muted = Color.rgb(195, 198, 220)
    private val pickerCode = 4201
    private lateinit var clockPreview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(22, 24, 45)
        window.navigationBarColor = Color.rgb(22, 24, 45)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(18).toFloat() }

    private fun label(s: String, size: Float = 15f, color: Int = white, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun addSection(parent: LinearLayout, title: String) {
        parent.addView(label(title, 12f, muted, true).apply {
            setPadding(0, dp(20), 0, dp(9))
        })
    }

    private fun actionButton(title: String, action: () -> Unit) =
        Button(this).apply {
            text = title
            setOnClickListener { action() }
        }

    private fun render() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(34, 37, 72), Color.rgb(18, 20, 39))
            )
        }
        page.addView(label("‹  iOS Fusion Settings", 22f, white, true).apply {
            setOnClickListener { finish() }
            setPadding(0, 0, 0, dp(12))
        })

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = rounded(0x33FFFFFF)
            setOnClickListener { startActivity(Intent(this@SettingsActivity, LockScreenPreviewActivity::class.java)) }
        }
        preview.addView(label("LOCK SCREEN PREVIEW", 11f, muted, true))
        clockPreview = label("09:41", prefs.getInt("clock_size", 48).toFloat(), prefs.getInt("clock_color", white), true)
        clockPreview.gravity = Gravity.CENTER
        preview.addView(clockPreview)
        preview.addView(label("Tap to open full preview", 12f, muted).apply { gravity = Gravity.CENTER })
        page.addView(preview, LinearLayout.LayoutParams(-1, dp(170)))

        addSection(page, "WALLPAPER")
        page.addView(actionButton("Choose wallpaper from gallery") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, pickerCode)
        }, LinearLayout.LayoutParams(-1, dp(48)))
        page.addView(actionButton("Use default gradient") {
            prefs.edit().remove("wallpaper_uri").apply()
            Toast.makeText(this, "Default background selected", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(48)))

        addSection(page, "CLOCK")
        val sizeLabel = label("Clock size: ${prefs.getInt("clock_size", 48)} sp", 14f, white)
        page.addView(sizeLabel)
        page.addView(SeekBar(this).apply {
            max = 36
            progress = (prefs.getInt("clock_size", 48) - 36).coerceIn(0, 36)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val size = progress + 36
                    sizeLabel.text = "Clock size: $size sp"
                    clockPreview.textSize = size.toFloat()
                    if (fromUser) prefs.edit().putInt("clock_size", size).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })

        page.addView(label("Clock color", 14f, white, true).apply { setPadding(0, dp(10), 0, dp(7)) })
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "White" to Color.WHITE,
            "Lavender" to Color.rgb(205, 190, 255),
            "Mint" to Color.rgb(156, 255, 220),
            "Blue" to Color.rgb(145, 190, 255)
        ).forEach { (name, color) ->
            colors.addView(TextView(this).apply {
                text = name
                textSize = 10f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                background = rounded(color)
                setOnClickListener {
                    prefs.edit().putInt("clock_color", color).apply()
                    clockPreview.setTextColor(color)
                    Toast.makeText(this@SettingsActivity, "$name selected", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        }
        page.addView(colors)


        addSection(page, "HOME SCREEN")
        val gridLabel = label("Grid columns: ${prefs.getInt("grid_columns", 4)}", 14f, white)
        page.addView(gridLabel)
        page.addView(SeekBar(this).apply {
            max = 2
            progress = (prefs.getInt("grid_columns", 4) - 3).coerceIn(0, 2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val columns = progress + 3
                    gridLabel.text = "Grid columns: $columns"
                    if (fromUser) prefs.edit().putInt("grid_columns", columns).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        val iconLabel = label("Icon size: ${prefs.getInt("icon_size", 48)} dp", 14f, white)
        page.addView(iconLabel)
        page.addView(SeekBar(this).apply {
            max = 24
            progress = (prefs.getInt("icon_size", 48) - 40).coerceIn(0, 24)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val size = progress + 40
                    iconLabel.text = "Icon size: $size dp"
                    if (fromUser) prefs.edit().putInt("icon_size", size).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        page.addView(android.widget.Switch(this).apply {
            text = "Show app labels"
            setTextColor(white)
            isChecked = prefs.getBoolean("show_labels", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("show_labels", checked).apply() }
        })

        addSection(page, "QUICK ACCESS")
        page.addView(actionButton("Open Control Center") {
            startActivity(Intent(this, QuickPanelActivity::class.java))
        }, LinearLayout.LayoutParams(-1, dp(48)))
        page.addView(actionButton("Set iOS Fusion as default launcher") {
            try {
                val homeSettings = Intent("android.settings.HOME_SETTINGS")
                if (homeSettings.resolveActivity(packageManager) != null) {
                    startActivity(homeSettings)
                } else {
                    startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                }
            } catch (_: Exception) {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
        }, LinearLayout.LayoutParams(-1, dp(48)))

        addSection(page, "ABOUT")
        page.addView(label("iOS Fusion Launcher 2.0.0\nAndroid 8.0–12 supported (API 26–32)\nDesigned for OPPO A15s / Android 10\nAndroid's secure PIN, pattern and fingerprint remain in control.",
            13f, muted))
        setContentView(android.widget.ScrollView(this).apply { addView(page) })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickerCode && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString("wallpaper_uri", uri.toString()).apply()
                Toast.makeText(this, "Wallpaper saved. Return to Home to preview.", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Unable to save wallpaper access", Toast.LENGTH_LONG).show()
            }
        }
    }
}
