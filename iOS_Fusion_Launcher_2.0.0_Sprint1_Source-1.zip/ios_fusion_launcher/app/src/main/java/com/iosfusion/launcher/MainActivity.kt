package com.iosfusion.launcher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fusion", MODE_PRIVATE) }
    private val appWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private val appWidgetHost by lazy { AppWidgetHost(this, HOST_ID) }
    private val white = Color.WHITE
    private val softWhite = Color.rgb(226, 230, 245)
    private val muted = Color.rgb(164, 174, 202)
    private val accent = Color.rgb(177, 164, 255)

    private lateinit var content: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var searchInput: EditText
    private lateinit var categoryRow: LinearLayout
    private lateinit var homeWidgets: LinearLayout
    private var allApps: List<ResolveInfo> = emptyList()
    private var selectedCategory = "All"
    private var visibleAppsLimit = 24
    private var currentPage = PAGE_HOME
    private var pendingWidgetId = -1
    private var downX = 0f
    private var downY = 0f

    private val categories = listOf("All", "Communication", "Social", "Media", "Games", "Productivity", "Tools", "System", "Other")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.rgb(12, 15, 29)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        allApps = loadApps()
        buildShell()
        showHome()
    }

    override fun onStart() {
        super.onStart()
        try { appWidgetHost.startListening() } catch (_: Exception) {}
    }

    override fun onStop() {
        try { appWidgetHost.stopListening() } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        allApps = loadApps()
        if (::content.isInitialized) {
            when (currentPage) {
                PAGE_HOME -> showHome()
                PAGE_APPS -> renderApps(searchInput.text.toString())
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, strokeColor: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildShell() {
        val root = FrameLayout(this)
        val wallpaper = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(24, 27, 51))
        }
        val uri = prefs.getString("wallpaper_uri", null)
        if (!uri.isNullOrBlank()) {
            try { wallpaper.setImageURI(Uri.parse(uri)) } catch (_: Exception) {}
        }
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xC9101428.toInt(), 0xA5121730.toInt(), 0xF20B0E1B.toInt())
            )
        }, FrameLayout.LayoutParams(-1, -1))

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(38), dp(18), dp(8))
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(0x35FFFFFF, 25, 0x30FFFFFF)
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        listOf("⌂" to "Home", "▦" to "Apps", "⚙" to "Style").forEachIndexed { index, pair ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener {
                    when (index) {
                        0 -> showHome()
                        1 -> showApps()
                        else -> startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                    }
                }
            }
            item.addView(label(pair.first, 21f, white, true).apply { gravity = Gravity.CENTER })
            item.addView(label(pair.second, 10f, softWhite).apply { gravity = Gravity.CENTER })
            nav.addView(item, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        shell.addView(nav, LinearLayout.LayoutParams(-1, dp(58)).apply {
            topMargin = dp(9); bottomMargin = dp(5)
        })
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; false }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (abs(dx) > dp(90) && abs(dx) > abs(dy) * 1.3f) {
                        if (dx < 0) showApps() else showHome()
                        true
                    } else false
                }
                else -> false
            }
        }
        setContentView(root)
    }

    private fun pageHeader(title: String, subtitle: String? = null): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label("iOS FUSION", 10f, accent, true))
        texts.addView(label(title, 23f, white, true))
        if (subtitle != null) texts.addView(label(subtitle, 11f, muted))
        header.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(roundButton("⚙") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        return header
    }

    private fun roundButton(symbol: String, action: () -> Unit) =
        TextView(this).apply {
            text = symbol
            textSize = 21f
            setTextColor(white)
            gravity = Gravity.CENTER
            background = rounded(0x35FFFFFF, 17, 0x30FFFFFF)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }

    private fun showHome() {
        currentPage = PAGE_HOME
        content.removeAllViews()
        content.addView(pageHeader("Good ${greeting()}", "Your space, your style"))
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(0x30FFFFFF, 25, 0x42FFFFFF)
            setPadding(dp(18), dp(13), dp(18), dp(13))
        }
        val clock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clock.addView(label(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 42f,
            prefs.getInt("clock_color", white), true))
        clock.addView(label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 12f, softWhite))
        hero.addView(clock, LinearLayout.LayoutParams(0, -2, 1f))
        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        right.addView(label("FUSION", 10f, accent, true))
        right.addView(label("${allApps.size} apps", 12f, softWhite))
        right.addView(label("Android launcher", 10f, muted))
        hero.addView(right)
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(18); bottomMargin = dp(13)
        })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(pill("＋  Add widget") { pickWidget() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(pill("▤  Edit style") {
            startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(8) })
        content.addView(actions)

        val widgetScroll = ScrollView(this).apply { clipToPadding = false }
        homeWidgets = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        widgetScroll.addView(homeWidgets)
        content.addView(widgetScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        renderHomeWidgets()

        val favoritesTitle = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        favoritesTitle.addView(label("Quick apps", 16f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        favoritesTitle.addView(label("See all  ›", 11f, accent).apply {
            setOnClickListener { showApps() }
        })
        content.addView(favoritesTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        val favorites = GridLayout(this).apply { columnCount = 4 }
        allApps.take(8).forEach { app -> favorites.addView(appCell(app, 46, true), GridLayout.LayoutParams().apply {
            width = 0; height = dp(82); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        }) }
        content.addView(favorites)
    }

    private fun renderHomeWidgets() {
        homeWidgets.removeAllViews()
        val ids = prefs.getStringSet(WIDGET_IDS, emptySet())?.toList().orEmpty()
        if (ids.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(0x20FFFFFF, 22, 0x30FFFFFF)
                setPadding(dp(16), dp(22), dp(16), dp(22))
            }
            empty.addView(label("＋", 30f, accent, true).apply { gravity = Gravity.CENTER })
            empty.addView(label("Add Android widgets to your Home Screen", 13f, softWhite, true).apply { gravity = Gravity.CENTER })
            empty.addView(label("Calendar, clock, weather and more", 11f, muted).apply { gravity = Gravity.CENTER })
            homeWidgets.addView(empty, LinearLayout.LayoutParams(-1, dp(128)).apply {
                topMargin = dp(6); bottomMargin = dp(8)
            })
            return
        }
        ids.forEach { raw ->
            val id = raw.toIntOrNull() ?: return@forEach
            val info = appWidgetManager.getAppWidgetInfo(id) ?: return@forEach
            try {
                val hostView: AppWidgetHostView = appWidgetHost.createView(this, id, info)
                hostView.setAppWidget(id, info)
                homeWidgets.addView(hostView, LinearLayout.LayoutParams(-1, dp(210)).apply {
                    topMargin = dp(5); bottomMargin = dp(8)
                })
                val remove = label("Remove widget", 11f, accent).apply {
                    gravity = Gravity.END
                    setPadding(0, dp(3), 0, dp(8))
                    setOnClickListener { removeWidget(id) }
                }
                homeWidgets.addView(remove)
            } catch (_: Exception) {}
        }
    }

    private fun pickWidget() {
        try {
            val id = appWidgetHost.allocateAppWidgetId()
            val pick = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            startActivityForResult(pick, REQUEST_PICK_WIDGET)
        } catch (_: Exception) {
            Toast.makeText(this, "Widget picker unavailable on this device", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeWidget(id: Int) {
        val ids = prefs.getStringSet(WIDGET_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.remove(id.toString())
        prefs.edit().putStringSet(WIDGET_IDS, ids).apply()
        try { appWidgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
        renderHomeWidgets()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_WIDGET) {
            val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
            if (resultCode != RESULT_OK || id < 0) {
                if (id >= 0) appWidgetHost.deleteAppWidgetId(id)
                return
            }
            val info = appWidgetManager.getAppWidgetInfo(id)
            if (info?.configure != null) {
                pendingWidgetId = id
                val config = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                    component = info.configure
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                }
                try { startActivityForResult(config, REQUEST_CONFIG_WIDGET) }
                catch (_: Exception) { saveWidget(id) }
            } else saveWidget(id)
        } else if (requestCode == REQUEST_CONFIG_WIDGET) {
            val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
            pendingWidgetId = -1
            if (resultCode == RESULT_OK && id >= 0) saveWidget(id)
            else if (id >= 0) appWidgetHost.deleteAppWidgetId(id)
        }
    }

    private fun saveWidget(id: Int) {
        val ids = prefs.getStringSet(WIDGET_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(id.toString())
        prefs.edit().putStringSet(WIDGET_IDS, ids).apply()
        showHome()
    }

    private fun pill(textValue: String, action: () -> Unit) =
        TextView(this).apply {
            text = textValue
            textSize = 12f
            setTextColor(white)
            gravity = Gravity.CENTER
            background = rounded(0x32FFFFFF, 18, 0x35FFFFFF)
            setOnClickListener { action() }
        }

    private fun showApps() {
        currentPage = PAGE_APPS
        content.removeAllViews()
        content.addView(pageHeader("App Library", "${allApps.size} installed apps"))
        searchInput = EditText(this).apply {
            hint = "⌕  Search apps"
            textSize = 14f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(0x35FFFFFF, 20, 0x35FFFFFF)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    visibleAppsLimit = 24
                    renderApps(s?.toString().orEmpty())
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        content.addView(searchInput, LinearLayout.LayoutParams(-1, dp(48)).apply {
            topMargin = dp(15); bottomMargin = dp(10)
        })
        categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val catScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(categoryRow)
        }
        content.addView(catScroll, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(8) })
        updateCategories()
        val scroll = ScrollView(this)
        appGrid = GridLayout(this).apply {
            columnCount = prefs.getInt("grid_columns", 4).coerceIn(3, 5)
            setPadding(0, dp(3), 0, dp(10))
        }
        scroll.addView(appGrid)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        renderApps("")
    }

    private fun updateCategories() {
        categoryRow.removeAllViews()
        categories.forEach { name ->
            categoryRow.addView(TextView(this).apply {
                text = name
                textSize = 11f
                setTextColor(if (name == selectedCategory) Color.rgb(22, 24, 42) else softWhite)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = rounded(if (name == selectedCategory) accent else 0x2CFFFFFF, 18)
                setOnClickListener {
                    selectedCategory = name
                    visibleAppsLimit = 24
                    updateCategories()
                    renderApps(searchInput.text.toString())
                }
            }, LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(7) })
        }
    }

    private fun renderApps(query: String) {
        if (!::appGrid.isInitialized || currentPage != PAGE_APPS) return
        appGrid.removeAllViews()
        val cols = prefs.getInt("grid_columns", 4).coerceIn(3, 5)
        appGrid.columnCount = cols
        val size = prefs.getInt("icon_size", 48).coerceIn(40, 64)
        val filtered = allApps.filter { app ->
            val name = app.loadLabel(packageManager).toString()
            (query.isBlank() || name.contains(query, true)) &&
                (selectedCategory == "All" || categoryFor(app) == selectedCategory)
        }
        val visibleApps = filtered.take(visibleAppsLimit)
        visibleApps.forEach { app ->
            appGrid.addView(appCell(app, size, prefs.getBoolean("show_labels", true)),
                GridLayout.LayoutParams().apply {
                    width = 0; height = dp(size + 34)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                })
        }
        if (filtered.isEmpty()) {
            appGrid.addView(label("No apps found", 14f, muted).apply {
                gravity = Gravity.CENTER
            }, GridLayout.LayoutParams().apply { width = -1; height = dp(70); columnSpec = GridLayout.spec(0, cols) })
        } else if (visibleApps.size < filtered.size) {
            val more = TextView(this).apply {
                text = "Show more  ·  ${filtered.size - visibleApps.size} remaining"
                textSize = 12f
                setTextColor(white)
                gravity = Gravity.CENTER
                background = rounded(0x32FFFFFF, 18, 0x35FFFFFF)
                setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener {
                    visibleAppsLimit = (visibleAppsLimit + 24).coerceAtMost(filtered.size)
                    renderApps(searchInput.text.toString())
                }
            }
            appGrid.addView(more, GridLayout.LayoutParams().apply {
                width = -1; height = dp(48)
                columnSpec = GridLayout.spec(0, cols)
            })
        }
    }

    private fun appCell(app: ResolveInfo, iconSize: Int, showLabel: Boolean): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(5), dp(2), dp(5))
            val icon = ImageView(this@MainActivity).apply {
                setImageDrawable(app.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = app.loadLabel(packageManager).toString()
            }
            addView(icon, LinearLayout.LayoutParams(dp(iconSize), dp(iconSize)))
            if (showLabel) addView(label(app.loadLabel(packageManager).toString(), 10f, softWhite).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, dp(21)))
            setOnClickListener {
                try {
                    packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)?.let { startActivity(it) }
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Unable to open app", Toast.LENGTH_SHORT).show()
                }
            }
            setOnLongClickListener {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:${app.activityInfo.packageName}")))
                } catch (_: Exception) {}
                true
            }
        }
    }

    private fun loadApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun categoryFor(app: ResolveInfo): String {
        val name = app.loadLabel(packageManager).toString().lowercase(Locale.getDefault())
        return when {
            listOf("whatsapp", "telegram", "messenger", "line", "messages", "phone", "dialer", "contacts").any { name.contains(it) } -> "Communication"
            listOf("facebook", "instagram", "tiktok", "discord", "snapchat", "reddit", "x ").any { name.contains(it) } -> "Social"
            listOf("youtube", "music", "video", "camera", "gallery", "photos", "spotify", "netflix", "mx player").any { name.contains(it) } -> "Media"
            listOf("game", "roblox", "free fire", "mobile legends", "minecraft", "pubg", "genshin").any { name.contains(it) } -> "Games"
            listOf("docs", "sheets", "slides", "office", "word", "excel", "drive", "classroom", "zoom", "meet").any { name.contains(it) } -> "Productivity"
            listOf("settings", "file", "clock", "calculator", "calendar", "browser", "maps", "cleaner", "manager").any { name.contains(it) } -> "Tools"
            listOf("system", "update", "launcher", "permission", "security").any { name.contains(it) } -> "System"
            else -> "Other"
        }
    }

    private fun greeting(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            hour < 11 -> "morning"
            hour < 16 -> "afternoon"
            else -> "evening"
        }
    }

    companion object {
        private const val HOST_ID = 2048
        private const val REQUEST_PICK_WIDGET = 701
        private const val REQUEST_CONFIG_WIDGET = 702
        private const val WIDGET_IDS = "home_widget_ids"
        private const val PAGE_HOME = 0
        private const val PAGE_APPS = 1
    }
}
