package com.iosfusion.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class QuickPanelActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 20, 39)
        window.navigationBarColor = Color.rgb(18, 20, 39)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(42, 46, 86), Color.rgb(18, 20, 39))
            )
        }
        root.addView(TextView(this).apply {
            text = "Control Center"
            textSize = 25f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(20))
        })
        val actions = listOf(
            "Wi-Fi settings" to android.provider.Settings.ACTION_WIFI_SETTINGS,
            "Bluetooth settings" to android.provider.Settings.ACTION_BLUETOOTH_SETTINGS,
            "Display & brightness" to android.provider.Settings.ACTION_DISPLAY_SETTINGS,
            "Sound settings" to android.provider.Settings.ACTION_SOUND_SETTINGS,
            "All system settings" to android.provider.Settings.ACTION_SETTINGS
        )
        actions.forEach { (title, action) ->
            root.addView(TextView(this).apply {
                text = "◉    $title    ›"
                textSize = 16f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = GradientDrawable().apply {
                    setColor(0x33FFFFFF)
                    cornerRadius = dp(18).toFloat()
                }
                setOnClickListener {
                    try { startActivity(Intent(action)) }
                    catch (_: Exception) { Toast.makeText(this@QuickPanelActivity, "Setting unavailable", Toast.LENGTH_SHORT).show() }
                }
            }, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })
        }
        root.addView(TextView(this).apply {
            text = "These shortcuts open Android system settings. The launcher does not change protected system toggles directly."
            textSize = 12f
            setTextColor(0xFFCACCE0.toInt())
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(root)
    }
}
