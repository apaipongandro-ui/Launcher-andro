package com.iosfusion.launcher

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LockScreenPreviewActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val prefs = getSharedPreferences("fusion", MODE_PRIVATE)
        val color = prefs.getInt("clock_color", Color.WHITE)
        val size = prefs.getInt("clock_size", 48).toFloat()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 80, 24, 36)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(52, 57, 105), Color.rgb(20, 22, 45), Color.rgb(70, 46, 94))
            )
        }
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            textSize = 17f
            setTextColor(0xFFDADCF0.toInt())
            gravity = Gravity.CENTER
        }
        val clock = TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            textSize = size
            setTextColor(color)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(date)
        root.addView(clock)
        root.addView(TextView(this).apply {
            text = "🔦                                      ◉"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 36)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "Swipe up to unlock  •  Preview only"
            textSize = 13f
            setTextColor(0xFFDADCF0.toInt())
            gravity = Gravity.CENTER
        })
        root.setOnClickListener { finish() }
        setContentView(root)
    }
}
