# Build iOS Fusion 2.0.0 Sprint 1 from an Android phone

1. Upload `iOS_Fusion_Launcher_2.0.0_Sprint1_Source.zip` to the root of your GitHub repository.
2. Open `.github/workflows/android-build.yml` in GitHub and replace its contents with the companion workflow file `iOS_Fusion_Launcher_2.0.0_Sprint1_Workflow.yml`.
3. Commit the workflow edit. GitHub Actions extracts the source archive, builds the debug APK in the cloud, and uploads the APK artifact.
4. Open Actions, select the newest successful run, and download `iOS-Fusion-Launcher-2.0.0-Sprint1`.
5. Extract the artifact ZIP and install `app-debug.apk`.

No PC or Android Studio is required. The project has not yet been compiled or tested on a physical device in this environment. If Actions fails, share the first failed step's log.
